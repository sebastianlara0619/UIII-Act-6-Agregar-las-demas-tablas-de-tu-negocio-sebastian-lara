from django.apps import AppConfig


class AppVentaTelefonosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_Venta_Telefonos'
