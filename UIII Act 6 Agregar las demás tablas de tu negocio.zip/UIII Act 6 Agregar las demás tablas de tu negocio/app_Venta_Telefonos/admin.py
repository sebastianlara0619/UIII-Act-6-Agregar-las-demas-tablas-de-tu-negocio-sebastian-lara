from django.contrib import admin
from .models import (
    Vendedor, Proveedor, Producto, Producto_Proveedor, 
    Categoria, Venta, DetalleVenta, Garantia
)

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre')

@admin.register(Vendedor)
class VendedorAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'apellido', 'cargo')

@admin.register(Proveedor)
class ProveedorAdmin(admin.ModelAdmin):
    # Corregido: 'nombre' es el campo correcto según tu modelo
    list_display = ('id', 'empresa', 'nombre', 'telefono', 'email')

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('id', 'marca', 'modelo', 'precio_venta', 'stock')
    list_filter = ('marca', 'categoria')

@admin.register(Producto_Proveedor)
class ProductoProveedorAdmin(admin.ModelAdmin):
    list_display = ('id', 'producto', 'proveedor', 'precio_compra') 

@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ('id', 'cliente', 'vendedor', 'fecha', 'total')

@admin.register(DetalleVenta)
class DetalleVentaAdmin(admin.ModelAdmin):
    list_display = ('id', 'venta', 'producto', 'cantidad', 'precio_unitario')

@admin.register(Garantia)
class GarantiaAdmin(admin.ModelAdmin):
    list_display = ('id', 'producto', 'cliente', 'fecha_vencimiento', 'estado')
    list_filter = ('estado',)