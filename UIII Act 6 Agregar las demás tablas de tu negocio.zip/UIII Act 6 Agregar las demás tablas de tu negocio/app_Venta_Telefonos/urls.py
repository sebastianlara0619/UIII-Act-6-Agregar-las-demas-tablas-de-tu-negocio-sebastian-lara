from django.urls import path
from . import views

urlpatterns = [
    # ==========================================
    # INICIO
    # ==========================================
    path('', views.inicio_ventas, name='inicio_ventas'),

    # ==========================================
    # INVENTARIO / PRODUCTOS
    # ==========================================
    path('productos/', views.ver_productos, name='ver_productos'),
    path('productos/agregar/', views.agregar_producto, name='agregar_producto'),
    path('productos/actualizar/<int:producto_id>/', views.actualizar_producto, name='actualizar_producto'),
    path('productos/borrar/<int:producto_id>/', views.borrar_producto, name='borrar_producto'),

    # ==========================================
    # CATEGORÍAS
    # ==========================================
    path('categorias/', views.ver_categorias, name='ver_categorias'),
    path('categorias/agregar/', views.agregar_categoria, name='agregar_categoria'),
    path('categorias/actualizar/<int:id>/', views.actualizar_categoria, name='actualizar_categoria'),
    path('categorias/borrar/<int:id>/', views.borrar_categoria, name='borrar_categoria'),

    # ==========================================
    # VENTAS (¡Agregadas para el nuevo sistema de Clientes!)
    # ==========================================
    path('ventas/', views.ver_ventas, name='ver_ventas'),
    path('ventas/agregar/', views.agregar_venta, name='agregar_venta'),

    # ==========================================
    # DETALLE DE VENTAS
    # ==========================================
    path('ventas/detalles/', views.ver_detalle_venta, name='ver_detalle_venta'),
    path('ventas/detalles/agregar/', views.agregar_detalle_venta, name='agregar_detalle_venta'),
    path('ventas/detalles/actualizar/<int:id>/', views.actualizar_detalle_venta, name='actualizar_detalle_venta'),
    path('ventas/detalles/borrar/<int:id>/', views.borrar_detalle_venta, name='borrar_detalle_venta'),

    # ==========================================
    # GARANTÍAS (Actualizado)
    # ==========================================
    path('garantias/', views.ver_garantias, name='ver_garantias'),
    path('garantias/agregar/', views.agregar_garantia, name='agregar_garantia'),
    path('garantias/actualizar/<int:id>/', views.actualizar_garantia, name='actualizar_garantia'), # Agregada
    path('garantias/borrar/<int:id>/', views.borrar_garantia, name='borrar_garantia'),

    # ==========================================
    # PROVEEDORES
    # ==========================================
    path('proveedores/', views.ver_proveedores, name='ver_proveedores'),
    path('proveedores/agregar/', views.agregar_proveedor, name='agregar_proveedor'),
    path('proveedores/actualizar/<int:proveedor_id>/', views.actualizar_proveedor, name='actualizar_proveedor'),
    path('proveedores/borrar/<int:proveedor_id>/', views.borrar_proveedor, name='borrar_proveedor'),

    # ==========================================
    # VENDEDORES
    # ==========================================
    path('vendedores/', views.ver_vendedores, name='ver_vendedores'),
    path('vendedores/agregar/', views.agregar_vendedor, name='agregar_vendedor'),
    path('vendedores/actualizar/<int:vendedor_id>/', views.actualizar_vendedor, name='actualizar_vendedor'),
    path('vendedores/borrar/<int:vendedor_id>/', views.borrar_vendedor, name='borrar_vendedor'),
]