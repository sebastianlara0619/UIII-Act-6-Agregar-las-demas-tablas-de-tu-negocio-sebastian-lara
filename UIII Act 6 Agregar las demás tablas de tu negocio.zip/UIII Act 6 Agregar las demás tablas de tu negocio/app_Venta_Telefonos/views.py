from django.shortcuts import render, redirect, get_object_or_404
from .models import (
    Vendedor, Proveedor, Producto, Producto_Proveedor, 
    Categoria, Venta, DetalleVenta, Garantia
)
from django.utils import timezone

# ==========================================
# SECCION: INICIO
# ==========================================
def inicio_ventas(request):
    """Pagina principal del sistema."""
    return render(request, 'inicio.html')

# ==========================================
# SECCION: VENDEDORES
# ==========================================
def ver_vendedores(request):
    vendedores = Vendedor.objects.all()
    return render(request, 'vendedor/ver_vendedores.html', {'vendedores': vendedores})

def agregar_vendedor(request):
    if request.method == 'POST':
        Vendedor.objects.create(
            nombre=request.POST.get('nombre'),
            apellido=request.POST.get('apellido'),
            cargo=request.POST.get('cargo'),
            telefono=request.POST.get('telefono'),
            email=request.POST.get('email'),
            fecha_contratacion=request.POST.get('fecha_contratacion'),
            salario=request.POST.get('salario')
        )
        return redirect('ver_vendedores')
    return render(request, 'vendedor/agregar_vendedor.html')

def actualizar_vendedor(request, vendedor_id):
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.nombre = request.POST.get('nombre')
        vendedor.apellido = request.POST.get('apellido')
        vendedor.cargo = request.POST.get('cargo')
        vendedor.telefono = request.POST.get('telefono')
        vendedor.email = request.POST.get('email')
        vendedor.fecha_contratacion = request.POST.get('fecha_contratacion')
        vendedor.salario = request.POST.get('salario')
        vendedor.save()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/actualizar_vendedor.html', {'vendedor': vendedor})

def borrar_vendedor(request, vendedor_id):
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.delete()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/borrar_vendedor.html', {'vendedor': vendedor})

# ==========================================
# SECCION: PROVEEDORES
# ==========================================
def ver_proveedores(request):
    proveedores = Proveedor.objects.all().order_by('-id') 
    return render(request, 'proveedor/ver_proveedor.html', {'proveedores': proveedores})

def agregar_proveedor(request):
    if request.method == 'POST':
        Proveedor.objects.create(
            nombre=request.POST.get('nombre'),
            empresa=request.POST.get('empresa'),
            telefono=request.POST.get('telefono'),
            email=request.POST.get('email'),
            direccion=request.POST.get('direccion'),
            ciudad=request.POST.get('ciudad')
        )
        return redirect('ver_proveedores')
    return render(request, 'proveedor/agregar_proveedor.html')

def actualizar_proveedor(request, proveedor_id):
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.nombre = request.POST.get('nombre')
        proveedor.empresa = request.POST.get('empresa')
        proveedor.telefono = request.POST.get('telefono')
        proveedor.email = request.POST.get('email')
        proveedor.direccion = request.POST.get('direccion')
        proveedor.ciudad = request.POST.get('ciudad')
        proveedor.save()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/actualizar_proveedor.html', {'proveedor': proveedor})

def borrar_proveedor(request, proveedor_id):
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.delete()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/borrar_proveedor.html', {'proveedor': proveedor})

# ==========================================
# SECCION: INVENTARIO / PRODUCTOS
# ==========================================
def ver_productos(request):
    productos = Producto.objects.all().prefetch_related('producto_proveedores__proveedor')
    return render(request, 'inventario/ver_productos.html', {'productos': productos})

def agregar_producto(request):
    if request.method == 'POST':
        nuevo_celular = Producto.objects.create(
            nombre=request.POST.get('nombre'),
            marca=request.POST.get('marca'),
            modelo=request.POST.get('modelo'),
            precio_venta=request.POST.get('precio_venta'),
            stock=request.POST.get('stock'),
            descripcion=request.POST.get('descripcion'),
            categoria_id=request.POST.get('categoria_id')
        )
        Producto_Proveedor.objects.create(
            producto=nuevo_celular,
            proveedor_id=request.POST.get('proveedor_id'),
            precio_compra=request.POST.get('precio_compra'),
            garantia_meses=request.POST.get('garantia', 12)
        )
        return redirect('ver_productos')
    
    proveedores = Proveedor.objects.all()
    categorias = Categoria.objects.all()
    return render(request, 'inventario/agregar_producto.html', {'proveedores': proveedores, 'categorias': categorias})

def actualizar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    if request.method == 'POST':
        producto.nombre = request.POST.get('nombre')
        producto.marca = request.POST.get('marca')
        producto.modelo = request.POST.get('modelo')
        producto.precio_venta = request.POST.get('precio_venta')
        producto.stock = request.POST.get('stock')
        producto.categoria_id = request.POST.get('categoria_id')
        producto.save()
        return redirect('ver_productos')
    
    categorias = Categoria.objects.all()
    return render(request, 'inventario/actualizar_producto.html', {'producto': producto, 'categorias': categorias})

def borrar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_productos')
    return render(request, 'inventario/borrar_producto.html', {'producto': producto})

# ==========================================
# SECCION: CATEGORIAS
# ==========================================
def ver_categorias(request):
    categorias = Categoria.objects.all()
    return render(request, 'categoria/ver_categoria.html', {'categorias': categorias})

def agregar_categoria(request):
    if request.method == 'POST':
        Categoria.objects.create(
            nombre=request.POST.get('nombre'),
            descripcion=request.POST.get('descripcion')
        )
        return redirect('ver_categorias')
    return render(request, 'categoria/agregar_categoria.html')

def actualizar_categoria(request, id):
    categoria = get_object_or_404(Categoria, id=id)
    if request.method == 'POST':
        categoria.nombre = request.POST.get('nombre')
        categoria.descripcion = request.POST.get('descripcion')
        categoria.save()
        return redirect('ver_categorias')
    return render(request, 'categoria/actualizar_categoria.html', {'categoria': categoria})

def borrar_categoria(request, id):
    categoria = get_object_or_404(Categoria, id=id)
    if request.method == 'POST':
        categoria.delete()
        return redirect('ver_categorias')
    return render(request, 'categoria/borrar_categoria.html', {'categoria': categoria})

# ==========================================
# SECCION: VENTAS Y DETALLES
# ==========================================
def ver_ventas(request):
    ventas = Venta.objects.all().order_by('-fecha')
    return render(request, 'venta/ver_ventas.html', {'ventas': ventas})

def agregar_venta(request):
    if request.method == 'POST':
        Venta.objects.create(
            cliente=request.POST.get('cliente'), 
            vendedor_id=request.POST.get('vendedor_id'),
            total=request.POST.get('total', 0)
        )
        return redirect('ver_ventas')
    vendedores = Vendedor.objects.all()
    return render(request, 'venta/agregar_venta.html', {'vendedores': vendedores})

def ver_detalle_venta(request):
    detalles = DetalleVenta.objects.all().select_related('venta', 'producto').order_by('-id')
    return render(request, 'detalle_venta/ver_detalle_venta.html', {'detalles': detalles})

def agregar_detalle_venta(request):
    """Lógica corregida: Crea Venta (Folio) y Detalle en un solo paso."""
    if request.method == 'POST':
        cliente = request.POST.get('cliente')
        vendedor_id = request.POST.get('vendedor')
        producto_id = request.POST.get('producto')
        cantidad = int(request.POST.get('cantidad'))
        precio = float(request.POST.get('precio_unitario'))

        # 1. Crear la Venta primero (Folio)
        vendedor = get_object_or_404(Vendedor, id=vendedor_id)
        nueva_venta = Venta.objects.create(
            cliente=cliente,
            vendedor=vendedor,
            fecha=timezone.now(),
            total=precio * cantidad
        )

        # 2. Crear el Detalle vinculado
        DetalleVenta.objects.create(
            venta=nueva_venta,
            producto_id=producto_id,
            cantidad=cantidad,
            precio_unitario=precio
        )
        return redirect('ver_detalle_venta')
    
    vendedores = Vendedor.objects.all()
    productos = Producto.objects.all()
    return render(request, 'detalle_venta/agregar_detalle_venta.html', {
        'vendedores': vendedores, 
        'productos': productos
    })

def actualizar_detalle_venta(request, id):
    detalle = get_object_or_404(DetalleVenta, id=id)
    if request.method == 'POST':
        # Actualizamos datos del detalle
        detalle.cantidad = int(request.POST.get('cantidad'))
        detalle.precio_unitario = float(request.POST.get('precio_unitario'))
        detalle.producto_id = request.POST.get('producto')
        detalle.save()
        
        # Actualizamos datos de la venta vinculada (Cliente)
        detalle.venta.cliente = request.POST.get('cliente')
        detalle.venta.total = detalle.cantidad * detalle.precio_unitario
        detalle.venta.save()
        
        return redirect('ver_detalle_venta')
    
    productos = Producto.objects.all()
    return render(request, 'detalle_venta/actualizar_detalle_venta.html', {
        'detalle': detalle,
        'productos': productos
    })

def borrar_detalle_venta(request, id):
    detalle = get_object_or_404(DetalleVenta, id=id)
    venta_asociada = detalle.venta
    if request.method == 'POST':
        detalle.delete()
        venta_asociada.delete() # Borramos el folio para no dejar ventas vacías
        return redirect('ver_detalle_venta')
    return render(request, 'detalle_venta/borrar_detalle_venta.html', {'detalle': detalle})

# ==========================================
# SECCION: GARANTIAS
# ==========================================
def ver_garantias(request):
    garantias = Garantia.objects.all().select_related('producto').order_by('-id')
    return render(request, 'garantia/ver_garantia.html', {'garantias': garantias})

def agregar_garantia(request):
    if request.method == 'POST':
        Garantia.objects.create(
            producto_id=request.POST.get('producto'),
            cliente=request.POST.get('cliente'), 
            fecha_vencimiento=request.POST.get('fecha_vencimiento'),
            estado=request.POST.get('estado'),
            observaciones=request.POST.get('observaciones')
        )
        return redirect('ver_garantias')
    
    productos = Producto.objects.all()
    return render(request, 'garantia/agregar_garantia.html', {'productos': productos})

def actualizar_garantia(request, id):
    garantia = get_object_or_404(Garantia, id=id)
    if request.method == 'POST':
        garantia.producto_id = request.POST.get('producto')
        garantia.cliente = request.POST.get('cliente')
        garantia.fecha_vencimiento = request.POST.get('fecha_vencimiento')
        garantia.estado = request.POST.get('estado')
        garantia.observaciones = request.POST.get('observaciones')
        garantia.save()
        return redirect('ver_garantias')
    
    productos = Producto.objects.all()
    return render(request, 'garantia/actualizar_garantia.html', {
        'garantia': garantia,
        'productos': productos
    })

def borrar_garantia(request, id):
    garantia = get_object_or_404(Garantia, id=id)
    if request.method == 'POST':
        garantia.delete()
        return redirect('ver_garantias')
    return render(request, 'garantia/borrar_garantia.html', {'garantia': garantia})