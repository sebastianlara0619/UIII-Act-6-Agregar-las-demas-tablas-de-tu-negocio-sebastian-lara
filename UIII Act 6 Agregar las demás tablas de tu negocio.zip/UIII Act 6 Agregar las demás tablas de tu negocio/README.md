# UIII_Act_3_aplicaci-n_funcionando_sobre_una_tabla_de_3_Django
sistema de administración de venta de teléfonos con proveedores funcionales
<img width="1920" height="1080" alt="image" src="https://github.com/user-attachments/assets/f5705182-cbe5-418b-96e1-2ed55047220a" />
<img width="1920" height="1080" alt="image" src="https://github.com/user-attachments/assets/71e141b8-a11c-4157-89c8-7117656c7cf1" />
<img width="1902" height="710" alt="image" src="https://github.com/user-attachments/assets/ef30db24-8ca6-458f-831e-b0d6941c8cb8" />
